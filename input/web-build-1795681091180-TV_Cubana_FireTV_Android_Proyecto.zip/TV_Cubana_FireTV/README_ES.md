# TV Cubana para Amazon Fire TV — proyecto Android

Adaptación inicial de la aplicación Roku adjunta. La pantalla principal usa tres tarjetas horizontales, fondo oscuro y selección azul/cian inspirada en Fire TV. Incluye navegación con mando, reproducción HLS con ExoPlayer, imágenes de respaldo por canal y retorno con BACK.

## Compatibilidad prevista
- `minSdk 22` (Android 5.1 / base de Fire OS 5.x).
- `targetSdk 28` para mantener compatibilidad con Fire OS antiguo mientras se valida en dispositivos recientes.
- ExoPlayer 2.19.1, con módulo HLS.

## Canales
Se conservaron literalmente las tres URL HLS y la asignación de imágenes de respaldo de `ChannelScene.brs` del ZIP Roku 1.2.

## Generar APK
1. Abre esta carpeta en Android Studio (versión compatible con Android Gradle Plugin 8.7.3).
2. Instala Android SDK Platform 35 y Build Tools sugeridos por Android Studio.
3. Espera la sincronización de Gradle y descarga de dependencias Maven.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Notas de validación
Este es un proyecto fuente preparado para compilar; no se adjunta un APK compilado. El entorno de trabajo no tiene Android SDK ni Gradle instalados, así que no se ha podido compilar ni probar en un Fire TV real. La reproducción de cada URL y el comportamiento del timeout deben validarse en el dispositivo. Los servicios HLS pueden cambiar o bloquear solicitudes según red, cabeceras o disponibilidad.
