# TV Cubana para Android / Amazon Fire TV — proyecto fuente

Proyecto Android Java con tres canales HLS, navegación por mando, ExoPlayer y pantallas de respaldo por canal.

## Compatibilidad configurada
- `minSdk 22` (Android 5.1; base compatible con Fire OS 5.x).
- `targetSdk 28`.
- Android Gradle Plugin 8.7.3 y `compileSdk 35`.
- ExoPlayer 2.19.1 con soporte HLS.

## Canales
Se conservaron literalmente las tres URL HLS del proyecto fuente recibido.

## Compilar APK
1. Abrir la carpeta `TV_Cubana_FireTV` en Android Studio.
2. Instalar Android SDK Platform 35 y aceptar las dependencias que Android Studio solicite.
3. Sincronizar Gradle.
4. Elegir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de validación
Este paquete es el proyecto fuente, no un APK compilado. El entorno de preparación no dispone de Gradle ni Android SDK, por lo que no fue posible compilarlo aquí ni probarlo en un Fire TV físico.

## Fotografías promocionales
Se conserva el conjunto de imágenes que venía en el proyecto recibido. No se han sustituido todavía por nuevas fotografías de MINTUR/Cuba Travel: el portal oficial identifica y promociona destinos como Viñales, Varadero, La Habana y Trinidad, pero una imagen publicada en un portal no implica automáticamente permiso de reutilización en una aplicación. Antes de integrar esas fotografías hay que confirmar su autorización/licencia y descargar los originales aprobados. Se evita presentar imágenes generadas como si fueran fotografías reales.
