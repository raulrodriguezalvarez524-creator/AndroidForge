package com.tvcubana.firetv;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 11, 16);
    private static final int PANEL = Color.rgb(22, 28, 38);
    private static final int CYAN = Color.rgb(0, 168, 224);
    private static final int WHITE = Color.WHITE;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private LinearLayout home;
    private PlayerView playerView;
    private ImageView noSignal;
    private ExoPlayer player;
    private Runnable timeoutRunnable;
    private boolean playerScreen = false;
    private int currentChannel = -1;

    private final Channel[] channels = new Channel[] {
        new Channel("Cubavisión", "https://cdn.teveo.cu/live/video/A36pWmuWvZBQskuZ/ngrp:9KJTMRBAm2BbnsYK.stream/playlist.m3u8", R.drawable.channel1, R.drawable.no_signal_cubavision),
        new Channel("Canal Caribe", "https://cdn.teveo.cu/live/video/A36pWmuWvZBQskuZ/ngrp:CKZ3s6Wuv4gDjndG.stream/playlist.m3u8", R.drawable.channel2, R.drawable.no_signal_canal_caribe),
        new Channel("Cubavisión Internacional", "https://cdn.teveo.cu/live/video/A36pWmuWvZBQskuZ/ngrp:gppfydfzpSUn9Udy.stream/playlist.m3u8", R.drawable.channel3, R.drawable.no_signal_cubavision_internacional)
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildHome();
    }

    private void buildHome() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        ImageView backdrop = new ImageView(this);
        backdrop.setImageResource(R.drawable.background);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.20f);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));

        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(54), dp(30), dp(54), dp(26));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(home, hp);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.icon);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        header.addView(icon, new LinearLayout.LayoutParams(dp(78), dp(64)));
        TextView title = text("TV Cubana", 36, WHITE, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(18);
        header.addView(title, tp);
        home.addView(header);

        TextView stripe = text("▰  ▰  ▰", 18, CYAN, true);
        stripe.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(28));
        sp.topMargin = dp(3);
        home.addView(stripe, sp);

        TextView heading = text("SELECCIONA TU CANAL", 20, Color.rgb(225, 233, 242), true);
        LinearLayout.LayoutParams hdp = new LinearLayout.LayoutParams(-1, dp(42));
        hdp.topMargin = dp(12);
        home.addView(heading, hdp);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1f);
        cp.topMargin = dp(8);
        home.addView(cards, cp);
        for (int i = 0; i < channels.length; i++) {
            final int index = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setFocusable(true);
            card.setFocusableInTouchMode(true);
            card.setPadding(dp(14), dp(16), dp(14), dp(14));
            card.setBackground(cardBackground(false));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(0, dp(236), 1f);
            if (i > 0) cardParams.leftMargin = dp(18);
            cards.addView(card, cardParams);

            ImageView logo = new ImageView(this);
            logo.setImageResource(channels[i].logo);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            card.addView(logo, new LinearLayout.LayoutParams(-1, dp(142)));
            TextView name = text(channels[i].name, 19, WHITE, true);
            name.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, dp(48));
            np.topMargin = dp(10);
            card.addView(name, np);
            card.setOnFocusChangeListener((v, focused) -> v.setBackground(cardBackground(focused)));
            card.setOnClickListener(v -> startChannel(index));
            card.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                    startChannel(index); return true;
                }
                return false;
            });
        }
        TextView footer = text("LA TELEVISIÓN CUBANA, EN UN SOLO CANAL", 15, Color.rgb(205, 216, 229), true);
        footer.setGravity(Gravity.CENTER);
        home.addView(footer, new LinearLayout.LayoutParams(-1, dp(42)));

        setContentView(root);
        root.setFocusableInTouchMode(true);
        root.requestFocus();
        // Focus the first card for immediate remote-control navigation.
        if (cards.getChildCount() > 0) cards.getChildAt(0).requestFocus();
    }

    private void startChannel(int index) {
        currentChannel = index;
        playerScreen = true;
        if (player != null) { player.release(); player = null; }
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);

        root.removeAllViews();
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        noSignal = new ImageView(this);
        noSignal.setScaleType(ImageView.ScaleType.FIT_XY);
        noSignal.setImageResource(channels[index].noSignal);
        noSignal.setVisibility(View.GONE);
        root.addView(noSignal, new FrameLayout.LayoutParams(-1, -1));

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 5.1; Fire TV) AppleWebKit/537.36 Chrome/131.0 Safari/537.36")
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(java.util.Collections.singletonMap("Referer", "https://teveo.cu/"));
        MediaSource.Factory mediaFactory = new DefaultMediaSourceFactory(httpFactory);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaFactory)
                .setLoadControl(new DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 1500, 3000).build())
                .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) cancelTimeout();
            }
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_ENDED) showNoSignal();
            }
            @Override public void onPlayerError(PlaybackException error) { showNoSignal(); }
        });
        player.setMediaItem(new MediaItem.Builder().setUri(channels[index].url).setMimeType("application/x-mpegURL").build());
        player.prepare();
        player.play();
        timeoutRunnable = this::showNoSignal;
        handler.postDelayed(timeoutRunnable, 25000);
    }

    private void showNoSignal() {
        if (!playerScreen || noSignal == null) return;
        cancelTimeout();
        if (player != null) player.stop();
        playerView.setVisibility(View.GONE);
        noSignal.setVisibility(View.VISIBLE);
        noSignal.requestFocus();
    }

    private void cancelTimeout() {
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
        timeoutRunnable = null;
    }

    private void returnHome() {
        playerScreen = false;
        cancelTimeout();
        if (player != null) { player.release(); player = null; }
        buildHome();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (playerScreen && event.getAction() == KeyEvent.ACTION_UP && event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            returnHome(); return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) { player.release(); player = null; }
        cancelTimeout();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    private GradientDrawable cardBackground(boolean focused) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(focused ? Color.rgb(29, 51, 67) : PANEL);
        d.setCornerRadius(dp(12));
        d.setStroke(dp(focused ? 3 : 1), focused ? CYAN : Color.rgb(55, 66, 80));
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private static class Channel {
        final String name, url; final int logo, noSignal;
        Channel(String n, String u, int l, int s) { name=n; url=u; logo=l; noSignal=s; }
    }
}
